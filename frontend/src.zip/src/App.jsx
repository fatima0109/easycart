import { Navigate, Route, Routes } from "react-router-dom";
import { useEffect } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';

import HomePage from "./pages/HomePage";
import SignUpPage from "./pages/SignUpPage";
import LoginPage from "./pages/LoginPage";
import AdminPage from "./pages/AdminPage";
import CategoryPage from "./pages/CategoryPage";
import CartPage from "./pages/CartPage";
import PurchaseSuccessPage from "./pages/PurchaseSuccessPage";
import PurchaseCancelPage from "./pages/PurchaseCancelPage";
import SearchResultsPage from "./pages/SearchResultsPage";
import OrderHistoryPage from "./pages/OrderHistoryPage";
import InfoPage from "./pages/InfoPage"; 
import ProfilePage from "./pages/ProfilePage"; 

import CreateProductForm from "./components/CreateProductForm";
import ProductsList from "./components/ProductsList";
import AnalyticsTab from "./components/AnalyticsTab";
import OrdersList from "./components/OrdersList";

import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import LoadingSpinner from "./components/LoadingSpinner";

import { Toaster } from "react-hot-toast";
import { useUserStore } from "./stores/useUserStore";
import { useCartStore } from "./stores/useCartStore";

function App() {
	const { user, checkAuth, checkingAuth } = useUserStore();
	const { getCartItems } = useCartStore();

	useEffect(() => {
		checkAuth();
	}, [checkAuth]);

	useEffect(() => {
		if (!user) return;
		getCartItems();
	}, [getCartItems, user]);

	if (checkingAuth) return <LoadingSpinner />;

	return (
		<div className='min-h-screen bg-[#F5F3EF] text-[#222222] relative overflow-hidden flex flex-col font-sans'>
			<Navbar />
			{/* Added Bootstrap 'container' class here for standard grid alignment */}
			<div className='relative pt-24 flex-grow container'>
				<Routes>
					<Route path='/' element={<HomePage />} />
					<Route path='/search' element={<SearchResultsPage />} />
					<Route path='/category/:category' element={<CategoryPage />} />
					<Route path='/info/:type' element={<InfoPage />} />
					<Route path='/signup' element={!user ? <SignUpPage /> : <Navigate to="/" />} />
					<Route path='/login' element={!user ? <LoginPage /> : <Navigate to="/" />} />
					
					{/* PROFILE ROUTES */}
					<Route path='/profile' element={user ? <ProfilePage /> : <Navigate to='/login' />}>
						<Route index element={<Navigate to="orders" />} />
						<Route path='orders' element={<OrderHistoryPage />} />
						<Route path='me' element={<div className="p-4 text-[#1F2A44] font-bold">Personal Info Section</div>} />
						<Route path='settings' element={<div className="p-4 text-[#1F2A44] font-bold">Settings Section</div>} />
						<Route path='wishlist' element={<div className="p-4 text-[#1F2A44] font-bold">My Wishlist Section</div>} />
					</Route>
					
					{/* ADMIN ROUTES */}
					<Route path='/secret-dashboard' element={user?.role === "admin" ? <AdminPage /> : <Navigate to='/login' />}>
						<Route index element={<Navigate to="analytics" />} />
						<Route path='create' element={<CreateProductForm />} />
						<Route path='products' element={<ProductsList />} />
						<Route path='analytics' element={<AnalyticsTab />} />
						<Route path='orders' element={<OrdersList />} />
					</Route>
					
					<Route path='/cart' element={user ? <CartPage /> : <Navigate to='/login' />} />
					<Route path='/purchase-success' element={user ? <PurchaseSuccessPage /> : <Navigate to='/login' />} />
					<Route path='/purchase-cancel' element={user ? <PurchaseCancelPage /> : <Navigate to='/login' />} />
				</Routes>
			</div>
			<Footer />
			<Toaster position="top-center" />
		</div>
	);
}

export default App;