import { useEffect } from "react";
import { useProductStore } from "../stores/useProductStore";
import { useParams } from "react-router-dom";
import { motion } from "framer-motion";
import ProductCard from "../components/ProductCard";

const CategoryPage = () => {
  const { fetchProductsByCategory, products } = useProductStore();
  const { category } = useParams();

  useEffect(() => {
    fetchProductsByCategory(category);
  }, [fetchProductsByCategory, category]);

  return (
    // Use 'bg-light' or your custom variable from index.css
    <div className="min-h-screen py-5" style={{ backgroundColor: '#F5F3EF' }}>
      
      {/* BOOTSTRAP: Using 'container' for centered, responsive layout */}
      <div className="container mt-5">
        
        {/* Category Title */}
        <motion.h1
          className="text-center display-4 fw-bold mb-5"
          style={{ color: '#1F2A44', letterSpacing: '-1px' }}
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          {category.charAt(0).toUpperCase() + category.slice(1)} Collection
        </motion.h1>

        {/* BOOTSTRAP PRODUCT GRID 
            row-cols-1: Mobile (1 card)
            row-cols-sm-2: Small Tablets (2 cards)
            row-cols-md-3: Large Tablets (3 cards)
            row-cols-lg-4: Desktop (4 cards)
            g-4: Gutter spacing between cards
        */}
        <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
          
          {/* Empty State Logic */}
          {products?.length === 0 && (
            <div className="col-12 py-5 text-center">
              <h2 className="text-muted fw-bold">
                No products found in this category.
              </h2>
            </div>
          )}

          {/* Mapping through products using Bootstrap columns */}
          {products?.map((product) => (
            <div className="col d-flex" key={product._id}>
              {/* Wrapping ProductCard in 'col' and adding 'd-flex' ensures 
                  all cards in a row have equal height automatically */}
              <ProductCard product={product} />
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};

export default CategoryPage;