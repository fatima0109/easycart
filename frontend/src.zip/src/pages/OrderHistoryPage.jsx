import { useEffect } from "react";
import { useOrderStore } from "../stores/useOrderStore";
import { motion } from "framer-motion";
import { Package } from "lucide-react";

const OrderHistoryPage = () => {
	const { orders, fetchUserOrders, loading } = useOrderStore();

	useEffect(() => {
		fetchUserOrders();
	}, [fetchUserOrders]);

	return (
		<div className='max-w-4xl mx-auto px-4 py-8 min-h-screen'>
			<h1 className='text-3xl font-bold text-[#1F2A44] mb-8'>Your Order History</h1>

			{orders.length === 0 ? (
				<div className='text-center py-12 bg-white rounded-xl border border-[#E0E0E0]'>
					<Package className='mx-auto h-12 w-12 text-[#9E9E9E] mb-4' />
					<p className='text-[#6B6B6B]'>You haven't placed any orders yet.</p>
				</div>
			) : (
				<div className='space-y-6'>
					{orders.map((order) => (
						<motion.div
							key={order._id}
							initial={{ opacity: 0 }}
							animate={{ opacity: 1 }}
							className='bg-white p-6 rounded-xl border border-[#E0E0E0] shadow-sm'
						>
							<div className='flex justify-between items-start mb-4'>
								<div>
									<p className='text-xs text-[#9E9E9E]'>Order ID: {order._id}</p>
									<p className='text-sm font-semibold text-[#1F2A44]'>
										Placed on: {new Date(order.createdAt).toLocaleDateString()}
									</p>
								</div>
								<span className='px-3 py-1 rounded-full text-xs font-bold uppercase bg-[#1F2A44]/10 text-[#1F2A44]'>
									{order.status}
								</span>
							</div>

							<div className='border-t border-[#F0F0F0] pt-4'>
								<p className='text-lg font-bold text-[#C97C5D]'>Total: ${order.totalAmount.toFixed(2)}</p>
							</div>
						</motion.div>
					))}
				</div>
			)}
		</div>
	);
};
export default OrderHistoryPage;