import React from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { User, ShoppingBag, Settings, Heart } from 'lucide-react';

const ProfilePage = () => {
  return (
    <div className='min-h-screen pt-20 px-4'>
      <div className='max-w-6xl mx-auto flex flex-col md:flex-row gap-8'>
        {/* Sidebar */}
        <aside className='w-full md:w-64 space-y-2'>
          <NavLink to="/profile/me" className={({isActive}) => `flex items-center gap-3 p-3 rounded-lg ${isActive ? 'bg-emerald-600' : 'hover:bg-gray-800'}`}>
            <User size={20} /> My Profile
          </NavLink>
          <NavLink to="/profile/orders" className={({isActive}) => `flex items-center gap-3 p-3 rounded-lg ${isActive ? 'bg-emerald-600' : 'hover:bg-gray-800'}`}>
            <ShoppingBag size={20} /> Order History
          </NavLink>
          <NavLink to="/profile/wishlist" className={({isActive}) => `flex items-center gap-3 p-3 rounded-lg ${isActive ? 'bg-emerald-600' : 'hover:bg-gray-800'}`}>
            <Heart size={20} /> Wishlist
          </NavLink>
          <NavLink to="/profile/settings" className={({isActive}) => `flex items-center gap-3 p-3 rounded-lg ${isActive ? 'bg-emerald-600' : 'hover:bg-gray-800'}`}>
            <Settings size={20} /> Account Settings
          </NavLink>
        </aside>

        {/* Content Area */}
        <main className='flex-1 bg-gray-800 p-6 rounded-xl border border-gray-700'>
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default ProfilePage;