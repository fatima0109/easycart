import { Link } from "react-router-dom";
import { useCartStore } from "../stores/useCartStore";
import { motion } from "framer-motion";
import { ShoppingCart } from "lucide-react";
import CartItem from "../components/CartItem";
import PeopleAlsoBought from "../components/PeopleAlsoBought";
import OrderSummary from "../components/OrderSummary";
import GiftCouponCard from "../components/GiftCouponCard";

const CartPage = () => {
  const { cart } = useCartStore();

  return (
    <div className="py-5" style={{backgroundColor: 'var(--bg-light)', minHeight: '100vh'}}>
      <div className="container mt-5">
        <div className="row">
          {/* Main Content (8 columns on large screens) */}
          <div className="col-lg-8">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              {cart.length === 0 ? (
                <EmptyCartUI />
              ) : (
                <div className="d-flex flex-column gap-3 mb-4">
                  {cart?.map((item) => (
                    <div className="card border-0 shadow-sm rounded-3 p-3" key={item._id}>
                      <CartItem item={item} />
                    </div>
                  ))}
                </div>
              )}
              {cart.length > 0 && <PeopleAlsoBought />}
            </motion.div>
          </div>

          {/* Sidebar (4 columns on large screens) */}
          {cart.length > 0 && (
            <div className="col-lg-4 mt-4 mt-lg-0">
              <div className="sticky-top" style={{top: '100px'}}>
                <div className="card border-0 shadow-sm mb-3">
                  <div className="card-body">
                    <OrderSummary />
                  </div>
                </div>
                <div className="card border-0 shadow-sm">
                  <div className="card-body">
                    <GiftCouponCard />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CartPage;