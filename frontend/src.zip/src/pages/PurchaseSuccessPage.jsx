// frontend/src/pages/PurchaseSuccessPage.jsx
import { ArrowRight, CheckCircle, HandHeart, Loader, AlertCircle } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useCartStore } from "../stores/useCartStore";
import axios from "../api/axios";
import Confetti from "react-confetti";
import { motion } from "framer-motion";

/**
 * PurchaseSuccessPage Component - Professional Formal Redesign
 * Integrates checkout verification and cart persistence cleanup
 */
const PurchaseSuccessPage = () => {
	const [isProcessing, setIsProcessing] = useState(true);
	const { clearCart } = useCartStore();
	const [error, setError] = useState(null);
	const navigate = useNavigate();

	useEffect(() => {
		const handleCheckoutSuccess = async (sessionId) => {
			try {
				// 1. Confirm order creation and backend cart cleanup
				await axios.post("/payments/checkout-success", { sessionId });
				
				// 2. Clear local Zustand state (The Persistence Loop)
				clearCart();
			} catch (error) {
				console.error("Order verification error:", error);
				setError("We couldn't verify your order automatically. Please check your email for confirmation.");
			} finally {
				setIsProcessing(false);
			}
		};

		const sessionId = new URLSearchParams(window.location.search).get("session_id");
		if (sessionId) {
			handleCheckoutSuccess(sessionId);
		} else {
			setIsProcessing(false);
			setError("Invalid session. No transaction record was found.");
		}
	}, [clearCart]);

	// LOADING STATE
	if (isProcessing) {
		return (
			<div className='min-h-screen flex items-center justify-center bg-[#F5F3EF]'>
				<div className='flex flex-col items-center gap-4 text-center'>
					<Loader className='h-12 w-12 animate-spin text-[#1F2A44]' />
					<p className='text-[#222222] font-bold uppercase tracking-widest text-sm'>Verifying Transaction...</p>
				</div>
			</div>
		);
	}

	// ERROR STATE
	if (error) {
		return (
			<div className='min-h-screen flex items-center justify-center px-4 bg-[#F5F3EF]'>
				<div className='max-w-md w-full bg-white rounded-2xl shadow-xl p-8 border border-[#D9534F]/30 text-center'>
					<AlertCircle className='text-[#D9534F] w-16 h-16 mx-auto mb-4' />
					<h2 className='text-2xl font-bold text-[#D9534F] mb-2'>Order Update</h2>
					<p className='text-[#6B6B6B] mb-6'>{error}</p>
					<Link
						to='/'
						className='inline-flex items-center gap-2 bg-[#1F2A44] text-white px-8 py-3 rounded-lg font-bold hover:bg-[#162033] transition-all'
					>
						Return to Home
					</Link>
				</div>
			</div>
		);
	}

	return (
		<div className='min-h-screen flex items-center justify-center px-4 bg-[#F5F3EF] relative overflow-hidden'>

			{/* Success Card */}
			<motion.div
				initial={{ opacity: 0, scale: 0.95 }}
				animate={{ opacity: 1, scale: 1 }}
				transition={{ duration: 0.5 }}
				className='max-w-md w-full bg-white rounded-2xl shadow-2xl overflow-hidden border border-[#4CAF50]/20 relative z-10'
			>
				<div className='p-8 sm:p-10'>
					<div className='flex justify-center mb-6'>
						<div className='bg-[#4CAF50]/10 rounded-full p-4'>
							<CheckCircle className='text-[#4CAF50] w-16 h-16' />
						</div>
					</div>

					<h1 className='text-2xl sm:text-3xl font-extrabold text-center text-[#4CAF50] mb-3'>Payment Successful</h1>

					<p className='text-[#222222] text-center mb-1 font-bold'>Thank you for your purchase.</p>
					<p className='text-[#6B6B6B] text-center text-sm mb-8'>
						A confirmation email with your invoice has been dispatched.
					</p>

					{/* Order Details Box */}
					<div className='bg-[#FAFAFA] rounded-xl p-5 mb-8 border border-[#E0E0E0]'>
						<div className='flex items-center justify-between mb-3'>
							<span className='text-xs font-bold text-[#9E9E9E] uppercase'>Reference Number</span>
							<span className='text-sm font-bold text-[#1F2A44]'>
								#ORD-{Math.floor(Math.random() * 90000) + 10000}
							</span>
						</div>
						<div className='flex items-center justify-between'>
							<span className='text-xs font-bold text-[#9E9E9E] uppercase'>Delivery Schedule</span>
							<span className='text-sm font-bold text-[#4CAF50]'>3-5 Business Days</span>
						</div>
					</div>

					{/* Action Buttons */}
					<div className='space-y-4'>
						<button
							className='w-full inline-flex items-center justify-center gap-2 bg-[#1F2A44] hover:bg-[#162033] text-white font-bold py-3 px-6 rounded-lg transition-all duration-200 shadow-md group'
							onClick={() => navigate("/profile")}
						>
							<HandHeart className='h-5 w-5 text-[#C97C5D]' />
							Track My Order
						</button>
						<Link
							to='/'
							className='w-full inline-flex items-center justify-center gap-2 border border-[#1F2A44] text-[#1F2A44] bg-white hover:bg-[#F5F5F5] font-bold py-3 px-6 rounded-lg transition-all duration-200 group'
						>
							Continue Shopping
							<ArrowRight className='h-5 w-5 group-hover:translate-x-1 transition-transform duration-200' />
						</Link>
					</div>
				</div>
			</motion.div>
		</div>
	);
};

export default PurchaseSuccessPage;