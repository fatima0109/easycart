// frontend/src/pages/SearchResultsPage.jsx
import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { useProductStore } from "../stores/useProductStore";
import ProductCard from "../components/ProductCard";

const SearchResultsPage = () => {
  const { fetchFilteredProducts, products, loading } = useProductStore();
  const location = useLocation();

  useEffect(() => {
    const queryParams = new URLSearchParams(location.search);
    const search = queryParams.get("search");
    const category = queryParams.get("category");

    // Fetch products based on URL params
    fetchFilteredProducts({ search, category });
  }, [location.search, fetchFilteredProducts]);

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 min-h-screen">
      <h1 className="text-3xl font-bold mb-8 text-[#1F2A44]">Search Results</h1>
      
      {loading ? (
        <div className="flex justify-center items-center h-64">
           {/* You can replace this with your loading spinner if you have one */}
           <p className="text-[#6B6B6B] animate-pulse">Loading products...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {products.length > 0 ? (
            products.map((product) => <ProductCard key={product._id} product={product} />)
          ) : (
            <p className="text-[#6B6B6B] col-span-full text-center text-lg">No products found matching your criteria.</p>
          )}
        </div>
      )}
    </div>
  );
};

export default SearchResultsPage;