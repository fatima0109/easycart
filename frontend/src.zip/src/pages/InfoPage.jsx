import React from 'react';
import { useParams } from 'react-router-dom';

const InfoPage = () => {
  const { type } = useParams();

  const content = {
    about: { title: "About Us", text: "We are EasyCart, your number one source for all things quality." },
    contact: { title: "Contact Us", text: "Email us at support@easycart.com or call 1-800-EASY." },
    terms: { title: "Terms of Service", text: "By using our site, you agree to our terms..." },
    privacy: { title: "Privacy Policy", text: "Your data is safe with us. We do not sell info..." },
    faq: { title: "Frequently Asked Questions", text: "How long is shipping? Usually 3-5 days." },
    shipping: { title: "Shipping Policy", text: "We ship worldwide using eco-friendly packaging." },
    returns: { title: "Return Policy", text: "30-day money-back guarantee on all items." }
  };

  const page = content[type] || { title: "Page Not Found", text: "Sorry, that page doesn't exist." };

  return (
    <div className='min-h-screen pt-20 px-4 max-w-4xl mx-auto'>
      <h1 className='text-4xl font-bold text-emerald-400 mb-6'>{page.title}</h1>
      <div className='bg-gray-800 p-8 rounded-lg shadow-xl border border-gray-700'>
        <p className='text-gray-300 leading-relaxed'>{page.text}</p>
      </div>
    </div>
  );
};

export default InfoPage;