import { BarChart, PlusCircle, ShoppingBasket, Package } from "lucide-react";
import { useEffect } from "react";
import { motion } from "framer-motion";
import { Link, Outlet, useLocation } from "react-router-dom";
import { useProductStore } from "../stores/useProductStore";

const tabs = [
  { id: "analytics", label: "Analytics", icon: BarChart, path: "/secret-dashboard/analytics" },
  { id: "create", label: "Create Product", icon: PlusCircle, path: "/secret-dashboard/create" },
  { id: "products", label: "Products", icon: ShoppingBasket, path: "/secret-dashboard/products" },
  { id: "orders", label: "Orders", icon: Package, path: "/secret-dashboard/orders" },
];

const AdminPage = () => {
  const { fetchAllProducts } = useProductStore();
  const location = useLocation();

  useEffect(() => {
    fetchAllProducts();
  }, [fetchAllProducts]);

  return (
    <div className="min-h-screen relative overflow-hidden bg-[#F5F3EF]">
      <div className="relative z-10 container mx-auto px-4 py-8">
        <motion.h1
          className="text-3xl font-extrabold mb-8 text-center text-[#1F2A44] tracking-tight"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          Admin Management Suite
        </motion.h1>

        {/* Tab Navigation */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex bg-white border border-[#E0E0E0] rounded-full p-1.5 shadow-sm overflow-x-auto">
            {tabs.map((tab) => {
              const isActive = location.pathname === tab.path;
              return (
                <Link
                  key={tab.id}
                  to={tab.path}
                  className={`flex items-center px-6 py-2.5 mx-1 rounded-full font-bold text-sm transition-all whitespace-nowrap ${
                    isActive
                      ? "bg-[#1F2A44] text-white shadow-md"
                      : "text-[#6B6B6B] hover:text-[#1F2A44] hover:bg-[#F0F0F0]"
                  }`}
                >
                  <tab.icon className="mr-2 h-4 w-4" />
                  {tab.label}
                </Link>
              );
            })}
          </div>
        </div>

        {/* This renders the specific component based on the URL */}
        <motion.div 
          className="bg-white rounded-3xl border border-[#E0E0E0] shadow-xl p-6 md:p-10 min-h-[500px]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <Outlet /> 
        </motion.div>
      </div>
    </div>
  );
};

export default AdminPage;