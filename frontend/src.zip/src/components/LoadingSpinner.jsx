// frontend/src/components/LoadingSpinner.jsx
import { motion } from "framer-motion";

/**
 * LoadingSpinner Component - Professional Formal Redesign
 * Uses Beige background (#F5F3EF), Navy (#1F2A44), and Copper (#C97C5D).
 */
const LoadingSpinner = () => {
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-[#F5F3EF] z-50">
      <div className="relative">
        {/* Outer ring (subtle Navy border) */}
        <div className="w-20 h-20 rounded-full border-2 border-[#1F2A44]/10" />

        {/* Animated spinner ring (Navy and Copper) */}
        <motion.div
          className="absolute top-0 left-0 w-20 h-20 rounded-full border-t-2 border-r-2 border-transparent"
          style={{
            borderTopColor: "#1F2A44", // Deep Navy
            borderRightColor: "#C97C5D", // Muted Copper
          }}
          animate={{ rotate: 360 }}
          transition={{
            duration: 1,
            repeat: Infinity,
            ease: "linear",
          }}
        />

        {/* Inner pulsing dot (Deep Navy) */}
        <motion.div
          className="absolute top-1/2 left-1/2 w-3 h-3 bg-[#1F2A44] rounded-full"
          style={{ x: "-50%", y: "-50%" }}
          animate={{ scale: [1, 1.5, 1], opacity: [0.6, 1, 0.6] }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />

        {/* Screen reader text */}
        <div className="sr-only">Loading, please wait...</div>
      </div>

      {/* Loading text (Secondary Grey) */}
      <motion.p
        className="absolute bottom-1/4 text-[#6B6B6B] text-sm font-bold uppercase tracking-widest"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.5 }}
      >
        Loading Collections...
      </motion.p>
    </div>
  );
};

export default LoadingSpinner;