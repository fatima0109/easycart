import { motion, AnimatePresence } from "framer-motion";
import { X, ShoppingCart, Heart, Share2, Star, ChevronRight } from "lucide-react";
import toast from "react-hot-toast";
import { useUserStore } from "../stores/useUserStore";
import { useCartStore } from "../stores/useCartStore";
import { useState } from "react";

/**
 * ProductQuickView Component - Professional Formal Redesign
 * Uses Navy (#1F2A44), Beige (#F5F3EF), and Copper (#C97C5D)
 */
const ProductQuickView = ({ product, isOpen, onClose }) => {
  const { user } = useUserStore();
  const { addToCart } = useCartStore();
  const [quantity, setQuantity] = useState(1);

  const handleAddToCart = () => {
    if (!user) {
      toast.error("Please login to add products to cart");
      return;
    }
    for (let i = 0; i < quantity; i++) {
      addToCart(product);
    }
    setQuantity(1);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-[#1F2A44]/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-[#E0E0E0]"
          >
            {/* Close Button */}
            <div className="sticky top-0 flex justify-end p-4 bg-white border-b border-[#E0E0E0] z-10">
              <button
                onClick={onClose}
                className="text-[#6B6B6B] hover:text-[#1F2A44] transition"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              {/* Product Image */}
              <div className="flex justify-center bg-[#FAFAFA] rounded-xl p-4 border border-[#F0F0F0]">
                <img
                  src={product.image}
                  alt={product.name}
                  className="max-h-80 object-cover rounded-xl shadow-sm"
                />
              </div>

              {/* Product Info */}
              <div className="space-y-4">
                <h2 className="text-3xl font-bold text-[#222222]">{product.name}</h2>

                {/* Rating (Copper) */}
                <div className="flex items-center gap-2">
                  <div className="flex gap-1">
                    {[...Array(4)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-[#C97C5D] text-[#C97C5D]" />
                    ))}
                    <Star className="h-4 w-4 fill-[#E0E0E0] text-[#E0E0E0]" />
                  </div>
                  <span className="text-sm text-[#6B6B6B]">(4.0) 256 reviews</span>
                </div>

                {/* Price (Navy) */}
                <div className="space-y-2">
                  <p className="text-4xl font-extrabold text-[#1F2A44]">
                    ${product.price}
                  </p>
                  <p className="text-sm text-[#6B6B6B] font-medium uppercase tracking-tighter">Free shipping on orders over $50</p>
                </div>

                {/* Description (Beige box) */}
                {product.description && (
                  <div className="p-4 rounded-lg bg-[#F5F3EF] border border-[#E0E0E0]">
                    <p className="text-[#6B6B6B] text-sm leading-relaxed">{product.description}</p>
                  </div>
                )}

                {/* In Stock Badge (Success Green) */}
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#4CAF50] rounded-full"></div>
                  <span className="text-sm text-[#4CAF50] font-bold">In Stock - Ships within 2 days</span>
                </div>

                {/* Quantity Selector */}
                <div className="space-y-2">
                  <label className="text-sm font-bold text-[#222222]">Quantity</label>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-4 py-2 rounded-lg bg-[#F5F3EF] hover:bg-[#F0F0F0] text-[#1F2A44] border border-[#E0E0E0] transition font-bold"
                    >
                      −
                    </button>
                    <input
                      type="number"
                      min="1"
                      value={quantity}
                      onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-16 text-center px-2 py-2 rounded-lg bg-white border border-[#E0E0E0] text-[#222222] focus:border-[#C97C5D] focus:outline-none font-bold"
                    />
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="px-4 py-2 rounded-lg bg-[#F5F3EF] hover:bg-[#F0F0F0] text-[#1F2A44] border border-[#E0E0E0] transition font-bold"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="space-y-3 pt-4">
                  <button
                    onClick={handleAddToCart}
                    className="w-full flex items-center justify-center gap-2 rounded-lg bg-[#C97C5D] hover:bg-[#B96A4E] px-5 py-3 text-base font-bold text-white shadow-md transition-all duration-200"
                  >
                    <ShoppingCart className="h-5 w-5" />
                    Add {quantity > 1 ? `${quantity} items` : "to Cart"}
                  </button>

                  <div className="flex gap-3">
                    <button className="flex-1 flex items-center justify-center gap-2 rounded-lg border border-[#E0E0E0] hover:border-[#1F2A44] py-2.5 text-[#6B6B6B] hover:text-[#1F2A44] transition font-semibold bg-white">
                      <Heart className="h-5 w-5" />
                      Wishlist
                    </button>
                    <button className="flex-1 flex items-center justify-center gap-2 rounded-lg border border-[#E0E0E0] hover:border-[#1F2A44] py-2.5 text-[#6B6B6B] hover:text-[#1F2A44] transition font-semibold bg-white">
                      <Share2 className="h-5 w-5" />
                      Share
                    </button>
                  </div>
                </div>

                {/* Product Details (Neutral Borders) */}
                <div className="pt-4 border-t border-[#E0E0E0] space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-[#9E9E9E] font-medium uppercase tracking-tighter">SKU:</span>
                    <span className="text-[#222222] font-bold">PROD-{product._id?.slice(-4) || "0000"}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-[#9E9E9E] font-medium uppercase tracking-tighter">Category:</span>
                    <span className="text-[#222222] font-bold capitalize">{product.category || "Uncategorized"}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-[#9E9E9E] font-medium uppercase tracking-tighter">Availability:</span>
                    <span className="text-[#4CAF50] font-bold">International Shipping</span>
                  </div>
                </div>

                {/* Secure Checkout Badge (Beige) */}
                <div className="flex items-center gap-2 text-xs text-[#6B6B6B] rounded-lg bg-[#F5F3EF] p-3 font-medium">
                  <ChevronRight className="h-4 w-4 text-[#C97C5D]" />
                  Secure checkout with industry standard SSL encryption
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ProductQuickView;