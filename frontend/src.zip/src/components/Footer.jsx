import { Mail, Phone, MapPin, Share2, MessageCircle, Globe, Zap } from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";
import toast from "react-hot-toast";

const Footer = () => {
  const [email, setEmail] = useState("");
  const [isSubscribing, setIsSubscribing] = useState(false);

  const handleNewsletterSubmit = (e) => {
    e.preventDefault();
    if (!email) { toast.error("Enter email"); return; }
    setIsSubscribing(true);
    setTimeout(() => {
      toast.success("Subscribed!");
      setEmail(""); setIsSubscribing(false);
    }, 500);
  };

  return (
    <footer className="bg-[#1F2A44] text-gray-300 pt-5">
      <div className="container py-5">
        <div className="row g-5">
          {/* Company Info */}
          <div className="col-lg-3 col-md-6">
            <div className="d-flex align-items-center gap-2 mb-4">
              <div className="bg-white rounded p-1"><span className="text-[#1F2A44] font-bold">S</span></div>
              <span className="h4 text-white font-bold mb-0">ShopHub</span>
            </div>
            <p className="small text-muted mb-4">Elevating everyday living through curated excellence and premium quality.</p>
            <div className="d-flex gap-2">
              <button className="btn btn-sm btn-outline-light border-0 opacity-75"><Share2 size={18}/></button>
              <button className="btn btn-sm btn-outline-light border-0 opacity-75"><Globe size={18}/></button>
            </div>
          </div>

          {/* Quick Links */}
          <div className="col-lg-2 col-md-6">
            <h6 className="text-white text-uppercase font-bold mb-4 small">Shop</h6>
            <ul className="list-unstyled small d-flex flex-column gap-2">
              <li><Link to="/" className="text-muted text-decoration-none hover:text-white">Home</Link></li>
              <li><Link to="/info/about" className="text-muted text-decoration-none hover:text-white">About Us</Link></li>
              <li><Link to="/info/faq" className="text-muted text-decoration-none hover:text-white">FAQ</Link></li>
            </ul>
          </div>

          {/* Support */}
          <div className="col-lg-2 col-md-6">
            <h6 className="text-white text-uppercase font-bold mb-4 small">Support</h6>
            <ul className="list-unstyled small d-flex flex-column gap-2">
              <li><Link to="/info/shipping" className="text-muted text-decoration-none hover:text-white">Shipping</Link></li>
              <li><Link to="/info/returns" className="text-muted text-decoration-none hover:text-white">Returns</Link></li>
              <li><Link to="/info/contact" className="text-muted text-decoration-none hover:text-white">Contact</Link></li>
            </ul>
          </div>

          {/* Newsletter */}
          <div className="col-lg-5 col-md-6">
            <h6 className="text-white text-uppercase font-bold mb-4 small">Stay Updated</h6>
            <p className="small text-muted mb-4">Subscribe for special offers and product updates.</p>
            <form onSubmit={handleNewsletterSubmit} className="d-flex gap-2">
              <input
                type="email"
                className="form-control bg-white border-0 py-2 rounded-lg"
                placeholder="Email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <button type="submit" className="btn btn-primary bg-[#C97C5D] border-0 px-4 font-bold whitespace-nowrap" disabled={isSubscribing}>
                {isSubscribing ? "..." : "Join"}
              </button>
            </form>
          </div>
        </div>

        {/* Contact Info Bar */}
        <div className="row mt-5 pt-4 border-top border-secondary text-center text-md-start">
          <div className="col-md-4 mb-3"><div className="d-flex align-items-center gap-3"><Phone size={18} className="text-[#C97C5D]"/><small>+1 (555) 123-4567</small></div></div>
          <div className="col-md-4 mb-3"><div className="d-flex align-items-center gap-3"><Mail size={18} className="text-[#C97C5D]"/><small>support@shophub.com</small></div></div>
          <div className="col-md-4 mb-3"><div className="d-flex align-items-center gap-3"><MapPin size={18} className="text-[#C97C5D]"/><small>123 Commerce St, NY</small></div></div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-4 pt-3 border-top border-secondary d-flex flex-column flex-md-row justify-content-between align-items-center small text-muted">
          <p className="mb-0">&copy; {new Date().getFullYear()} ShopHub Corporation. All rights reserved.</p>
          <div className="d-flex gap-4">
             <Link to="/info/terms" className="text-muted text-decoration-none">Terms</Link>
             <Link to="/info/privacy" className="text-muted text-decoration-none">Privacy</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;