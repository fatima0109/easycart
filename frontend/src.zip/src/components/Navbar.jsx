import { ShoppingCart, UserPlus, LogOut, Menu, X, MapPin, ChevronDown, Lock } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useUserStore } from "../stores/useUserStore";
import { useCartStore } from "../stores/useCartStore";
import SearchBar from "./SearchBar";

const Navbar = () => {
	const { user, logout } = useUserStore();
	const { cart } = useCartStore();
	const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
	const isAdmin = user?.role === "admin";

	return (
		<header className='fixed-top bg-white border-bottom shadow-sm'>
			{/* TOP SECTION */}
			<div className='container-fluid px-3 py-2'>
				<div className='row align-items-center g-2'>
					{/* LOGO & LOCATION */}
					<div className='col-auto d-flex align-items-center gap-3'>
						<button className="d-lg-none btn p-1" onClick={() => setIsMobileMenuOpen(true)}>
							<Menu size={24} />
						</button>
						
						<Link to='/' className='d-flex align-items-center text-decoration-none gap-2'>
							<div className='bg-dark rounded p-2 text-white fw-bold'>S</div>
							<span className='h4 mb-0 fw-bold d-none d-sm-inline text-dark'>ShopHub</span>
						</Link>

						<div className='d-none d-xl-flex align-items-center gap-1 border-start ps-3'>
							<MapPin size={18} className='text-muted' />
							<div className='lh-1'>
								<div className='small text-muted fw-bold text-uppercase' style={{fontSize: '10px'}}>Deliver to</div>
								<div className='small fw-bold text-dark'>Pakistan</div>
							</div>
						</div>
					</div>

					{/* SEARCH BAR (Center) */}
					<div className='col flex-grow-1 px-md-4'>
						<div className='search-container'>
							<div className='d-none d-md-flex align-items-center px-3 bg-light border-end small fw-bold'>
								All <ChevronDown size={14} className='ms-1' />
							</div>
							<div className='flex-grow-1 d-flex align-items-center px-2'>
								<SearchBar />
							</div>
							<button className='btn btn-custom-primary rounded-0 px-3'>
								<svg xmlns='http://www.w3.org/2000/svg' width="20" height="20" fill='none' viewBox='0 0 24 24' stroke='currentColor'>
									<path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z' />
								</svg>
							</button>
						</div>
					</div>

					{/* RIGHT ACTIONS */}
					<div className='col-auto d-flex align-items-center gap-2 gap-md-3'>
						{isAdmin && (
							<Link to='/secret-dashboard' className='btn btn-dark btn-sm d-none d-md-flex align-items-center gap-2'>
								<Lock size={14} /> <span>Admin</span>
							</Link>
						)}

						<Link to={user ? "/profile" : "/login"} className='text-decoration-none text-dark d-flex flex-column'>
							<span className='small text-muted d-none d-md-block' style={{fontSize: '11px'}}>Hello, {user ? user.name.split(" ")[0] : "Sign in"}</span>
							<span className='small fw-bold d-flex align-items-center'>Account <ChevronDown size={14} /></span>
						</Link>

						<Link to='/cart' className='position-relative p-2 text-dark'>
							<ShoppingCart size={24} />
							<span className='position-absolute top-0 start-100 translate-middle badge rounded-pill bg-custom-primary' style={{fontSize: '10px'}}>
								{Array.isArray(cart) ? cart.length : 0}
							</span>
						</Link>
					</div>
				</div>
			</div>

			{/* SUB-NAV - Use Bootstrap container for standard alignment */}
			<div className='bg-light border-top d-none d-md-block'>
				<div className='container py-2'>
					<nav className='nav gap-4 small fw-bold'>
						<Link to='/info/about' className='nav-link p-0 text-muted'>About Us</Link>
						<Link to='/info/faq' className='nav-link p-0 text-muted'>FAQ</Link>
						<Link to='/info/shipping' className='nav-link p-0 text-muted'>Shipping</Link>
						<Link to='/sell' className='nav-link p-0 text-muted ms-auto'>Sell on ShopHub</Link>
					</nav>
				</div>
			</div>
		</header>
	);
};

export default Navbar;