import { motion } from "framer-motion";
import toast from "react-hot-toast";
import { ShoppingCart, Star, Eye, Heart } from "lucide-react";
import { useUserStore } from "../stores/useUserStore";
import { useCartStore } from "../stores/useCartStore";
import { useState } from "react";
import ProductQuickView from "./ProductQuickView";
// Import the external JS helper
import { formatPrice } from "../utils/helpers";

const ProductCard = ({ product }) => {
  const { user } = useUserStore();
  const { addToCart } = useCartStore();
  const [_isQuickViewOpen, _setIsQuickViewOpen] = useState(false);
  const [isWishlisted, setIsWishlisted] = useState(false);

  const handleAddToCart = (e) => {
    e.stopPropagation();
    if (!user) {
      toast.error("Please login to add products to cart");
      return;
    }
    addToCart(product);
  };

  const _handleWishlist = (e) => {
    e.stopPropagation();
    if (!user) {
      toast.error("Please login to add to wishlist");
      return;
    }
    setIsWishlisted(!isWishlisted);
    toast.success(isWishlisted ? "Removed from wishlist" : "Added to wishlist");
  };

  return (
    <motion.div
      className="card h-100 border-0 shadow-sm group product-card-hover"
      whileHover={{ y: -5 }}
    >
      {/* IMAGE CONTAINER: Fixed Height for consistency */}
      <div className="position-relative overflow-hidden" style={{ height: '250px' }}>
        <img
          className="w-100 h-100 object-cover transition-transform"
          src={product.image}
          alt={product.name}
        />
        {/* Mobile-Friendly Badge */}
        <span className="badge bg-custom-primary position-absolute top-0 start-0 m-2">
          New
        </span>
      </div>

      <div className="card-body d-flex flex-column p-3">
        <div className="mb-2">
          <small className="text-muted fw-bold text-uppercase" style={{fontSize: '10px'}}>
            {product.category}
          </small>
          <h6 className="fw-bold text-dark mt-1 text-truncate">{product.name}</h6>
        </div>

        <div className="mt-auto">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <span className="h5 fw-bold text-dark mb-0">{formatPrice(product.price)}</span>
            <div className="d-flex text-warning">
              <Star size={12} fill="currentColor" />
              <Star size={12} fill="currentColor" />
              <Star size={12} fill="currentColor" />
              <Star size={12} fill="currentColor" />
            </div>
          </div>

          <button
            onClick={handleAddToCart}
            className="btn btn-dark w-100 py-2 fw-bold d-flex align-items-center justify-content-center gap-2"
          >
            <ShoppingCart size={18} /> Add to Cart
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default ProductCard;