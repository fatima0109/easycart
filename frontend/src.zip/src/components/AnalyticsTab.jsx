// frontend/src/components/AnalyticsTab.jsx
// eslint-disable-next-line no-unused-vars
import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import axios from "../api/axios";
import { Users, Package, ShoppingCart, DollarSign } from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

/**
 * AnalyticsTab Component - Professional Formal Redesign
 */
const AnalyticsTab = () => {
  const [analyticsData, setAnalyticsData] = useState({
    users: 0,
    products: 0,
    totalSales: 0,
    totalRevenue: 0,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [dailySalesData, setDailySalesData] = useState([]);

  useEffect(() => {
    const fetchAnalyticsData = async () => {
      try {
        const response = await axios.get("/analytics");
        setAnalyticsData(response.data.analyticsData);
        setDailySalesData(response.data.dailySalesData);
      } catch (error) {
        console.error("Error fetching analytics data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchAnalyticsData();
  }, []);

  // Shimmer effect using Neutral Border and Beige colors
  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 bg-[#F5F3EF]">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[...Array(4)].map((_, i) => (
            <div
              key={i}
              className="bg-white border border-[#E0E0E0] rounded-2xl p-6 animate-pulse"
            >
              <div className="h-4 bg-[#F5F3EF] rounded w-1/2 mb-4"></div>
              <div className="h-8 bg-[#F5F3EF] rounded w-3/4"></div>
            </div>
          ))}
        </div>
        <div className="bg-white border border-[#E0E0E0] rounded-2xl p-6 animate-pulse h-[400px]"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 min-h-screen bg-[#F5F3EF]">
      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        <AnalyticsCard
          title="Total Users"
          value={analyticsData.users.toLocaleString()}
          icon={Users}
          color="#1F2A44" // Navy
        />
        <AnalyticsCard
          title="Total Products"
          value={analyticsData.products.toLocaleString()}
          icon={Package}
          color="#1F2A44" // Navy
        />
        <AnalyticsCard
          title="Total Sales"
          value={analyticsData.totalSales.toLocaleString()}
          icon={ShoppingCart}
          color="#C97C5D" // Copper
        />
        <AnalyticsCard
          title="Total Revenue"
          value={`$${analyticsData.totalRevenue.toLocaleString()}`}
          icon={DollarSign}
          color="#C97C5D" // Copper
        />
      </div>

      {/* Sales & Revenue Chart */}
      <motion.div
        className="bg-white rounded-2xl p-6 shadow-sm border border-[#E0E0E0]"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        <h3 className="text-xl font-bold text-[#222222] mb-6 flex items-center gap-2">
          <span className="w-1.5 h-6 bg-[#C97C5D] rounded-full"></span>
          Daily Sales & Revenue Trends
        </h3>
        <ResponsiveContainer width="100%" height={400}>
          <LineChart data={dailySalesData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E0E0E0" vertical={false} />
            <XAxis
              dataKey="name"
              stroke="#6B6B6B"
              tick={{ fill: "#6B6B6B", fontSize: 12 }}
              tickLine={{ stroke: "#E0E0E0" }}
            />
            <YAxis
              yAxisId="left"
              stroke="#6B6B6B"
              tick={{ fill: "#6B6B6B", fontSize: 12 }}
              tickLine={{ stroke: "#E0E0E0" }}
              label={{
                value: "Sales (units)",
                angle: -90,
                position: "insideLeft",
                fill: "#6B6B6B",
                style: { fontSize: "12px", fontWeight: "600" },
              }}
            />
            <YAxis
              yAxisId="right"
              orientation="right"
              stroke="#6B6B6B"
              tick={{ fill: "#6B6B6B", fontSize: 12 }}
              tickLine={{ stroke: "#E0E0E0" }}
              label={{
                value: "Revenue ($)",
                angle: 90,
                position: "insideRight",
                fill: "#6B6B6B",
                style: { fontSize: "12px", fontWeight: "600" },
              }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "#FFFFFF",
                border: "1px solid #E0E0E0",
                borderRadius: "12px",
                color: "#222222",
                boxShadow: "0 4px 12px rgba(0,0,0,0.05)",
              }}
              itemStyle={{ fontSize: "14px" }}
            />
            <Legend
              wrapperStyle={{
                paddingTop: "20px",
              }}
            />
            <Line
              yAxisId="left"
              type="monotone"
              dataKey="sales"
              stroke="#C97C5D" // Copper
              strokeWidth={3}
              dot={{ r: 4, fill: "#C97C5D", strokeWidth: 0 }}
              activeDot={{ r: 6, stroke: "#fff", strokeWidth: 2 }}
              name="Sales"
            />
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="revenue"
              stroke="#1F2A44" // Navy
              strokeWidth={3}
              dot={{ r: 4, fill: "#1F2A44", strokeWidth: 0 }}
              activeDot={{ r: 6, stroke: "#fff", strokeWidth: 2 }}
              name="Revenue"
            />
          </LineChart>
        </ResponsiveContainer>
      </motion.div>
    </div>
  );
};

export default AnalyticsTab;

/**
 * Redesigned Analytics Card Component
 */
const AnalyticsCard = ({ title, value, icon: Icon, color }) => (
  <motion.div
    className="relative bg-white border border-[#E0E0E0] rounded-2xl p-6 shadow-sm overflow-hidden transition-all duration-300 hover:shadow-md group"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.4 }}
  >
    <div className="relative z-10 flex items-start justify-between">
      <div>
        <p className="text-[#6B6B6B] text-xs font-bold uppercase tracking-widest mb-2">
          {title}
        </p>
        <h3 className="text-[#1F2A44] text-3xl font-extrabold tracking-tight">
          {value}
        </h3>
      </div>
      <div
        className="p-3 rounded-xl transition-all duration-300 group-hover:scale-110"
        style={{ backgroundColor: `${color}10` }} // 10% opacity version of the color
      >
        <Icon className="h-6 w-6" style={{ color: color }} />
      </div>
    </div>

    {/* Subtle Accent Bottom Bar */}
    <div 
        className="absolute bottom-0 left-0 h-1 w-full transition-all duration-300 opacity-0 group-hover:opacity-100" 
        style={{ backgroundColor: color }}
    ></div>
  </motion.div>
);