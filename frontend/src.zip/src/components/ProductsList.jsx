// frontend/src/components/ProductsList.jsx
import { motion } from "framer-motion";
import { Trash, Star, Package } from "lucide-react";
import { useProductStore } from "../stores/useProductStore";

/**
 * ProductsList Component - Professional Formal Redesign
 * Uses Deep Navy (#1F2A44), Soft Beige (#F5F3EF), and Muted Copper (#C97C5D)
 */
const ProductsList = () => {
  const { deleteProduct, toggleFeaturedProduct, products } = useProductStore();

  return (
    <motion.div
      /* Use Bootstrap 'container-fluid' or 'container' for the outer wrapper */
      className="container-fluid py-4"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
    >
      {/* BOOTSTRAP CLASS: 'table-responsive' is the key for mobile tables */}
      <div className="table-responsive shadow-sm rounded-3 border bg-white">
        <table className="table table-hover align-middle mb-0">
          {/* Header - Formal Navy Styling */}
          <thead className="table-dark">
            <tr>
              <th className="px-4 py-3 border-0">Product Details</th>
              <th className="px-4 py-3 border-0">Unit Price</th>
              <th className="px-4 py-3 border-0">Category</th>
              <th className="px-4 py-3 border-0">Featured</th>
              <th className="px-4 py-3 border-0 text-end">Actions</th>
            </tr>
          </thead>

          <tbody className="bg-white">
            {products?.map((product) => (
              <motion.tr key={product._id}>
                {/* Product Image & Name */}
                <td className="px-4 py-3">
                  <div className="d-flex align-items-center gap-3">
                    <img
                      className="rounded border shadow-sm"
                      src={product.image}
                      style={{ width: '48px', height: '48px', objectFit: 'cover' }}
                      alt={product.name}
                    />
                    <span className="fw-bold text-dark">{product.name}</span>
                  </div>
                </td>

                <td className="px-4 py-3 fw-bold text-primary">
                  ${product.price.toFixed(2)}
                </td>

                <td className="px-4 py-3">
                  <span className="badge bg-light text-muted border px-3 py-2 text-uppercase">
                    {product.category}
                  </span>
                </td>

                <td className="px-4 py-3">
                  <button
                    onClick={() => toggleFeaturedProduct(product._id)}
                    className={`btn btn-sm ${product.isFeatured ? 'btn-warning' : 'btn-outline-secondary'}`}
                  >
                    <Star size={16} fill={product.isFeatured ? "white" : "none"} />
                  </button>
                </td>

                <td className="px-4 py-3 text-end">
                  <button
                    onClick={() => deleteProduct(product._id)}
                    className="btn btn-outline-danger btn-sm border-0"
                  >
                    <Trash size={18} />
                  </button>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
    </motion.div>
  );

};

export default ProductsList;