// frontend/src/components/FeaturedProducts.jsx
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ShoppingCart, ChevronLeft, ChevronRight, Star } from "lucide-react";
import { useCartStore } from "../stores/useCartStore";

/**
 * FeaturedProducts Component - Professional Formal Redesign
 * Uses Navy (#1F2A44), Beige (#F5F3EF), and Copper (#C97C5D)
 */
const FeaturedProducts = ({ featuredProducts }) => {
  // Carousel state
  const [currentIndex, setCurrentIndex] = useState(0);
  const [itemsPerPage, setItemsPerPage] = useState(4);

  const { addToCart } = useCartStore();

  // Update itemsPerPage based on window width (responsive)
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 640) setItemsPerPage(1);
      else if (window.innerWidth < 1024) setItemsPerPage(2);
      else if (window.innerWidth < 1280) setItemsPerPage(3);
      else setItemsPerPage(4);
    };

    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => prevIndex + itemsPerPage);
  };

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => prevIndex - itemsPerPage);
  };

  const productsArray = Array.isArray(featuredProducts) ? featuredProducts : [];

  const isStartDisabled = currentIndex === 0;
  const isEndDisabled = currentIndex >= productsArray.length - itemsPerPage;

  const cardVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  return (
    <div className="py-16 bg-[#FAFAFA]">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl sm:text-5xl font-extrabold text-[#1F2A44] mb-3">
            Featured Products
          </h2>
          <p className="text-[#6B6B6B] text-lg max-w-2xl mx-auto">
            Handpicked just for you – discover our most popular items
          </p>
          <div className="w-24 h-1 bg-[#C97C5D] rounded-full mx-auto mt-4"></div>
        </motion.div>

        {/* Carousel Container */}
        <div className="relative group">
          <div className="overflow-hidden rounded-2xl">
            <div
              className="flex transition-transform duration-500 ease-out"
              style={{ transform: `translateX(-${currentIndex * (100 / itemsPerPage)}%)` }}
            >
              {productsArray.map((product, idx) => (
                <div
                  key={product._id}
                  className="w-full sm:w-1/2 lg:w-1/3 xl:w-1/4 flex-shrink-0 px-3"
                >
                  <motion.div
                    variants={cardVariants}
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.05 }}
                    whileHover={{ y: -4 }}
                    className="bg-white rounded-2xl shadow-sm overflow-hidden h-full transition-all duration-300 hover:shadow-md border border-[#E0E0E0] group/card"
                  >
                    {/* Image Container */}
                    <div className="overflow-hidden relative">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-56 object-cover transition-transform duration-700 ease-out group-hover/card:scale-110"
                        loading="lazy"
                      />
                      <div className="absolute top-3 left-3 bg-[#C97C5D] text-white text-[10px] font-bold px-3 py-1 rounded-full shadow-md uppercase tracking-wider">
                        Featured
                      </div>
                    </div>

                    {/* Product Info */}
                    <div className="p-5">
                      <h3 className="text-lg font-bold text-[#222222] mb-1 line-clamp-1">
                        {product.name}
                      </h3>
                      <p className="text-[#C97C5D] text-sm mb-2 flex items-center gap-1">
                        <Star className="h-3 w-3 fill-[#C97C5D]" />
                        <Star className="h-3 w-3 fill-[#C97C5D]" />
                        <Star className="h-3 w-3 fill-[#C97C5D]" />
                        <Star className="h-3 w-3 fill-[#C97C5D]" />
                        <Star className="h-3 w-3 text-[#E0E0E0]" />
                        <span className="text-[#9E9E9E] text-xs ml-1">(24)</span>
                      </p>
                      <p className="text-2xl font-bold text-[#1F2A44] mb-4">
                        ${product.price.toFixed(2)}
                      </p>
                      <button
                        onClick={() => addToCart(product)}
                        className="w-full bg-[#C97C5D] hover:bg-[#B96A4E] text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 transform hover:scale-[1.02] flex items-center justify-center gap-2 shadow-sm"
                      >
                        <ShoppingCart className="h-5 w-5" />
                        Add to Cart
                      </button>
                    </div>
                  </motion.div>
                </div>
              ))}
            </div>
          </div>

          {/* Previous Button (Navy) */}
          <button
            onClick={prevSlide}
            disabled={isStartDisabled}
            className={`absolute top-1/2 -left-4 transform -translate-y-1/2 p-3 rounded-full transition-all duration-300 shadow-lg z-10 ${
              isStartDisabled
                ? "bg-[#D3D3D3] cursor-not-allowed opacity-50"
                : "bg-[#1F2A44] hover:bg-[#162033] text-white hover:scale-110 focus:outline-none"
            }`}
            aria-label="Previous products"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          {/* Next Button (Navy) */}
          <button
            onClick={nextSlide}
            disabled={isEndDisabled}
            className={`absolute top-1/2 -right-4 transform -translate-y-1/2 p-3 rounded-full transition-all duration-300 shadow-lg z-10 ${
              isEndDisabled
                ? "bg-[#D3D3D3] cursor-not-allowed opacity-50"
                : "bg-[#1F2A44] hover:bg-[#162033] text-white hover:scale-110 focus:outline-none"
            }`}
            aria-label="Next products"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Dots Indicator (Copper) */}
        {productsArray.length > itemsPerPage && (
          <div className="flex justify-center mt-8 gap-2">
            {Array.from({ length: Math.ceil(productsArray.length / itemsPerPage) }).map(
              (_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentIndex(idx * itemsPerPage)}
                  className={`h-2 rounded-full transition-all duration-300 ${
                    Math.floor(currentIndex / itemsPerPage) === idx
                      ? "w-8 bg-[#C97C5D]"
                      : "w-2 bg-[#E0E0E0] hover:bg-[#6B6B6B]"
                  }`}
                  aria-label={`Go to slide ${idx + 1}`}
                />
              )
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default FeaturedProducts;