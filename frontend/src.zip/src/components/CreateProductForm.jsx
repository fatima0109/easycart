import { useState } from "react";
import { motion } from "framer-motion";
import { PlusCircle, Upload, Loader, X } from "lucide-react";
import { useProductStore } from "../stores/useProductStore";

const categories = ["jeans", "t-shirts", "shoes", "glasses", "jackets", "suits", "bags"];

const CreateProductForm = () => {
  const [newProduct, setNewProduct] = useState({
    name: "", description: "", price: "", category: "", image: "",
  });

  const { createProduct, loading } = useProductStore();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await createProduct(newProduct);
      setNewProduct({ name: "", description: "", price: "", category: "", image: "" });
    } catch (error) { console.log(error); }
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setNewProduct({ ...newProduct, image: reader.result });
      reader.readAsDataURL(file);
    }
  };

  return (
    <motion.div
      className="card shadow-lg border-[#E0E0E0] rounded-2xl max-w-xl mx-auto overflow-hidden"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <div className="card-body p-4 p-md-5">
        <h2 className="card-title h3 font-bold text-[#1F2A44] mb-4">Create New Product</h2>

        <form onSubmit={handleSubmit} className="row g-3">
          <div className="col-12">
            <label className="form-label font-bold small text-uppercase">Product Name</label>
            <input
              type="text"
              className="form-control rounded-xl py-2 px-3 border-[#E0E0E0]"
              value={newProduct.name}
              onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
              required
            />
          </div>

          <div className="col-12">
            <label className="form-label font-bold small text-uppercase">Description</label>
            <textarea
              className="form-control rounded-xl py-2 px-3 border-[#E0E0E0]"
              rows="3"
              value={newProduct.description}
              onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
              required
            />
          </div>

          <div className="col-md-6">
            <label className="form-label font-bold small text-uppercase">Price ($)</label>
            <input
              type="number"
              className="form-control rounded-xl py-2 px-3 border-[#E0E0E0]"
              value={newProduct.price}
              onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
              required
            />
          </div>

          <div className="col-md-6">
            <label className="form-label font-bold small text-uppercase">Category</label>
            <select
              className="form-select rounded-xl py-2 px-3 border-[#E0E0E0]"
              value={newProduct.category}
              onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
              required
            >
              <option value="">Select...</option>
              {categories.map((cat) => <option key={cat} value={cat}>{cat.toUpperCase()}</option>)}
            </select>
          </div>

          <div className="col-12 mt-4">
            <label className="form-label font-bold small text-uppercase d-block mb-3">Product Image</label>
            <div className="d-flex align-items-center gap-4">
              <input type="file" id="image" className="d-none" accept="image/*" onChange={handleImageChange} />
              <label htmlFor="image" className="btn btn-outline-dark rounded-xl px-4 py-2 font-bold small">
                <Upload size={16} className="inline me-2" /> Upload
              </label>
              {newProduct.image && (
                <div className="position-relative">
                  <img src={newProduct.image} alt="Preview" className="rounded-lg shadow-sm" style={{width: '60px', height: '60px', objectFit: 'cover'}} />
                  <button type="button" onClick={() => setNewProduct({...newProduct, image: ''})} className="btn btn-danger btn-sm rounded-circle position-absolute top-0 start-100 translate-middle p-0" style={{width: '20px', height: '20px'}}><X size={12}/></button>
                </div>
              )}
            </div>
          </div>

          <div className="col-12 mt-4">
            <button
              type="submit"
              className="btn btn-primary w-100 bg-[#C97C5D] border-0 py-3 rounded-xl font-bold shadow-md"
              disabled={loading}
            >
              {loading ? <Loader className="animate-spin inline me-2" /> : <PlusCircle size={18} className="inline me-2" />}
              {loading ? "Creating..." : "Create Product"}
            </button>
          </div>
        </form>
      </div>
    </motion.div>
  );
};

export default CreateProductForm;