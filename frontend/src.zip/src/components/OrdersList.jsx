import { motion } from "framer-motion";
import { useOrderStore } from "../stores/useOrderStore";
import { useEffect } from "react";
import { Package, CheckCircle, Truck, XCircle } from "lucide-react";

const OrdersList = () => {
	const { fetchAllOrders, adminOrders, updateOrderStatus, loading } = useOrderStore();

	useEffect(() => {
		fetchAllOrders();
	}, [fetchAllOrders]);

	const statusConfig = {
		processing: { color: "text-blue-500", icon: Package },
		shipped: { color: "text-yellow-500", icon: Truck },
		delivered: { color: "text-green-500", icon: CheckCircle },
		cancelled: { color: "text-red-500", icon: XCircle },
	};

	return (
		<motion.div
			className='bg-white shadow-lg rounded-lg overflow-hidden max-w-5xl mx-auto'
			initial={{ opacity: 0, y: 20 }}
			animate={{ opacity: 1, y: 0 }}
			transition={{ duration: 0.8 }}
		>
			<table className='min-w-full divide-y divide-[#E0E0E0]'>
				<thead className='bg-[#F5F3EF]'>
					<tr>
						<th className='px-6 py-3 text-left text-xs font-medium text-[#6B6B6B] uppercase tracking-wider'>Customer</th>
						<th className='px-6 py-3 text-left text-xs font-medium text-[#6B6B6B] uppercase tracking-wider'>Total</th>
						<th className='px-6 py-3 text-left text-xs font-medium text-[#6B6B6B] uppercase tracking-wider'>Status</th>
						<th className='px-6 py-3 text-left text-xs font-medium text-[#6B6B6B] uppercase tracking-wider'>Action</th>
					</tr>
				</thead>
				<tbody className='bg-white divide-y divide-[#E0E0E0]'>
					{adminOrders.map((order) => (
						<tr key={order._id} className='hover:bg-gray-50'>
							<td className='px-6 py-4 whitespace-nowrap text-sm text-[#1F2A44]'>
								{order.user?.name || "Deleted User"} <br />
								<span className='text-xs text-[#9E9E9E]'>{order.user?.email}</span>
							</td>
							<td className='px-6 py-4 whitespace-nowrap text-sm text-[#1F2A44] font-bold'>
								${order.totalAmount.toFixed(2)}
							</td>
							<td className='px-6 py-4 whitespace-nowrap text-sm'>
								<span className={`flex items-center gap-2 font-semibold ${statusConfig[order.status].color}`}>
									{order.status}
								</span>
							</td>
							<td className='px-6 py-4 whitespace-nowrap text-sm'>
								<select
									value={order.status}
									onChange={(e) => updateOrderStatus(order._id, e.target.value)}
									className='bg-[#F0F0F0] border border-[#E0E0E0] text-[#1F2A44] text-xs rounded-lg px-2 py-1 focus:outline-none'
								>
									<option value='processing'>Processing</option>
									<option value='shipped'>Shipped</option>
									<option value='delivered'>Delivered</option>
									<option value='cancelled'>Cancelled</option>
								</select>
							</td>
						</tr>
					))}
				</tbody>
			</table>
		</motion.div>
	);
};
export default OrdersList;