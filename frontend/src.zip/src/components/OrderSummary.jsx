// frontend/src/components/OrderSummary.jsx
import { motion } from "framer-motion";
import { useCartStore } from "../stores/useCartStore";
import { useNavigate, Link } from "react-router-dom";
import { MoveRight, CreditCard, Tag, ShoppingBag } from "lucide-react";
import axios from "../api/axios";
import { toast } from "react-hot-toast";

/**
 * OrderSummary Component - Professional Formal Redesign
 * Uses Deep Navy (#1F2A44), Muted Copper (#C97C5D), and White (#FFFFFF)
 */
const OrderSummary = () => {
  const { total, subtotal, coupon, isCouponApplied, cart } = useCartStore();

  const savings = subtotal - total;
  const formattedSubtotal = subtotal.toFixed(2);
  const formattedTotal = total.toFixed(2);
  const formattedSavings = savings.toFixed(2);

  const navigate = useNavigate();

  const handlePayment = async () => {
    try {
      const res = await axios.post("/payments/create-checkout-session", {
        products: cart,
        couponCode: coupon ? coupon.code : null,
      });

      const session = res.data;
      navigate(`/purchase-success?session_id=${session.id}`);
    } catch (error) {
      console.error("Payment error:", error);
      toast.error(error?.response?.data?.message || error?.message || "Payment failed. Please try again.");
    }
  };

  return (
    <motion.div
      className="space-y-5 rounded-2xl border border-[#E0E0E0] bg-white p-5 shadow-sm sm:p-6 transition-all duration-300 hover:shadow-md"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Header */}
      <div className="flex items-center gap-2 pb-4 border-b border-[#E0E0E0]">
        <ShoppingBag className="h-5 w-5 text-[#1F2A44]" />
        <p className="text-xl font-bold text-[#1F2A44]">
          Order Summary
        </p>
      </div>

      <div className="space-y-4">
        {/* Price breakdown */}
        <div className="space-y-3">
          <dl className="flex items-center justify-between gap-4">
            <dt className="text-base text-[#6B6B6B]">Original price</dt>
            <dd className="text-base font-bold text-[#222222]">${formattedSubtotal}</dd>
          </dl>

          {savings > 0 && (
            <motion.dl
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center justify-between gap-4"
            >
              <dt className="text-base text-[#6B6B6B] flex items-center gap-1">
                <Tag className="h-4 w-4 text-[#4CAF50]" />
                Savings
              </dt>
              <dd className="text-base font-bold text-[#4CAF50]">-${formattedSavings}</dd>
            </motion.dl>
          )}

          {coupon && isCouponApplied && (
            <motion.dl
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center justify-between gap-4"
            >
              <dt className="text-base text-[#6B6B6B]">Coupon ({coupon.code})</dt>
              <dd className="text-base font-bold text-[#4CAF50]">-{coupon.discountPercentage}%</dd>
            </motion.dl>
          )}

          <dl className="flex items-center justify-between gap-4 border-t border-[#E0E0E0] pt-4 mt-2">
            <dt className="text-lg font-bold text-[#222222]">Total</dt>
            <dd className="text-2xl font-extrabold text-[#1F2A44]">
              ${formattedTotal}
            </dd>
          </dl>
        </div>

        {/* Checkout button (Copper Accent) */}
        <motion.button
          className="flex w-full items-center justify-center gap-2 rounded-lg bg-[#C97C5D] px-5 py-3 text-base font-bold text-white shadow-sm hover:bg-[#B96A4E] focus:outline-none focus:ring-2 focus:ring-[#C97C5D] transition-all duration-200"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handlePayment}
        >
          <CreditCard className="h-5 w-5" />
          Proceed to Checkout
        </motion.button>

        {/* Continue shopping link */}
        <div className="flex items-center justify-center gap-2 pt-2">
          <span className="text-sm text-[#9E9E9E]">or</span>
          <Link
            to="/"
            className="inline-flex items-center gap-1 text-sm font-bold text-[#1F2A44] hover:text-[#C97C5D] transition-colors duration-200 group"
          >
            Continue Shopping
            <MoveRight size={16} className="group-hover:translate-x-1 transition-transform duration-200" />
          </Link>
        </div>
      </div>
    </motion.div>
  );
};

export default OrderSummary;