// frontend/src/components/CartItem.jsx
import { Minus, Plus, Trash } from "lucide-react";
import { useCartStore } from "../stores/useCartStore";
import { motion } from "framer-motion";

/**
 * CartItem Component - Professional Formal Redesign
 * Uses Navy + Beige + Copper palette.
 */
const CartItem = ({ item }) => {
  const { removeFromCart, updateQuantity } = useCartStore();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="card border-0 shadow-sm mb-3 rounded-4" // Use Bootstrap Card
    >
      <div className="card-body p-3 p-md-4">
        {/* Responsive Flex: Column on mobile, Row on Medium+ */}
        <div className="d-flex flex-column flex-md-row align-items-center gap-4">
          
          {/* IMAGE: Fluid on mobile, fixed thumb on desktop */}
          <div className="flex-shrink-0" style={{ width: '100%', maxWidth: '120px' }}>
            <img
              className="img-fluid rounded-3 border" // Bootstrap 'img-fluid'
              src={item.image}
              alt={item.name}
              style={{ aspectRatio: '1/1', objectFit: 'cover' }}
            />
          </div>

          {/* PRODUCT INFO: Grows to fill space */}
          <div className="flex-grow-1 text-center text-md-start">
            <h5 className="fw-bold text-dark mb-1">{item.name}</h5>
            <p className="small text-muted mb-2 d-none d-sm-block">{item.description}</p>
            
            <button
              className="btn btn-link text-danger p-0 small fw-bold text-decoration-none"
              onClick={() => removeFromCart(item._id)}
            >
              <Trash size={14} className="me-1" /> Remove
            </button>
          </div>

          {/* CONTROLS: Stays aligned together */}
          <div className="d-flex align-items-center justify-content-between w-100 w-md-auto gap-4">
            <div className="d-flex align-items-center bg-light rounded-pill px-2 py-1">
              <button 
                className="btn btn-sm btn-light rounded-circle shadow-sm"
                onClick={() => updateQuantity(item._id, item.quantity - 1)}
              >
                <Minus size={14} />
              </button>
              <span className="px-3 fw-bold">{item.quantity}</span>
              <button 
                className="btn btn-sm btn-light rounded-circle shadow-sm"
                onClick={() => updateQuantity(item._id, item.quantity + 1)}
              >
                <Plus size={14} />
              </button>
            </div>
            
            <div className="text-end">
              <span className="h5 fw-bold text-primary mb-0">${item.price}</span>
            </div>
          </div>

        </div>
      </div>
    </motion.div>
  );
};

export default CartItem;