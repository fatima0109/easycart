// frontend/src/components/CategoryItem.jsx
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

/**
 * CategoryItem Component - Professional Formal Redesign
 * Uses Deep Navy (#1F2A44) and Muted Copper (#C97C5D)
 */
const CategoryItem = ({ category }) => {
  return (
    <motion.div
      className="relative overflow-hidden h-96 w-full rounded-2xl border border-[#E0E0E0] shadow-sm group bg-white"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5 }}
      whileHover={{ y: -8, boxShadow: "0px 12px 24px rgba(0,0,0,0.1)" }}
    >
      <Link to={"/category" + category.href} className="block h-full w-full">
        {/* Image with zoom on hover */}
        <img
          src={category.imageUrl}
          alt={category.name}
          className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
          loading="lazy"
        />

        {/* Gradient Overlay - Deep Navy to Transparent for a professional look */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#1F2A44] via-[#1F2A44]/40 to-transparent opacity-80 group-hover:opacity-95 transition-opacity duration-300" />

        {/* Content overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-6 z-10 transform transition-transform duration-300 group-hover:translate-y-[-4px]">
          <h3 className="text-white text-2xl md:text-3xl font-bold mb-2 tracking-tight">
            {category.name}
          </h3>
          
          <p className="text-gray-200 text-sm md:text-base mb-3 flex items-center gap-1 font-medium">
            Explore {category.name}
            <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
          </p>

          {/* Decorative underline using Muted Copper accent */}
          <div className="w-12 h-1 bg-gradient-to-r from-[#C97C5D] to-[#B96A4E] rounded-full group-hover:w-24 transition-all duration-300" />
        </div>
      </Link>
    </motion.div>
  );
};

export default CategoryItem;