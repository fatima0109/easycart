// frontend/src/stores/useOrderStore.js
import { create } from "zustand";
import axios from "../api/axios";
import { toast } from "react-hot-toast";

export const useOrderStore = create((set) => ({
	orders: [], // Current user's order history
	adminOrders: [], // All orders (Admin only)
	loading: false,

	// For Customers: Get their own order history
	fetchUserOrders: async () => {
		set({ loading: true });
		try {
			const res = await axios.get("/orders");
			// Ensure res.data is an array
			set({ orders: Array.isArray(res.data) ? res.data : [], loading: false });
		} catch (error) {
			set({ loading: false });
			toast.error(error.response?.data?.message || "Failed to fetch your orders");
		}
	},

	// For Admins: Get every order in the system
	fetchAllOrders: async () => {
		set({ loading: true });
		try {
			const res = await axios.get("/orders/all");
			set({ adminOrders: Array.isArray(res.data) ? res.data : [], loading: false });
		} catch (error) {
			set({ loading: false });
			toast.error(error.response?.data?.message || "Failed to fetch all orders");
		}
	},

	// For Admins: Change status (processing -> shipped, etc.)
	updateOrderStatus: async (orderId, status) => {
		try {
			const res = await axios.put(`/orders/${orderId}/status`, { status });
			
			// Update the specific order inside the adminOrders array
			set((state) => ({
				adminOrders: state.adminOrders.map((order) =>
					order._id === orderId ? { ...order, status: res.data.status } : order
				),
			}));
			
			toast.success(`Order marked as ${status}`);
		} catch (error) {
			toast.error(error.response?.data?.message || "Failed to update status");
		}
	},
}));